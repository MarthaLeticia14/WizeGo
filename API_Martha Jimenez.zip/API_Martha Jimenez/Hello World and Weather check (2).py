#!/usr/bin/env python
# coding: utf-8

# In[63]:


from flask import Flask, request
app = Flask(__name__)
import http.client,json

conn = http.client.HTTPSConnection("community-open-weather-map.p.rapidapi.com")
headers = {
    'x-rapidapi-host': "community-open-weather-map.p.rapidapi.com",
    'x-rapidapi-key': "9d0c00c170mshb1806f67f5f2a47p1986e8jsne1af605abe9c"
    }

@app.route('/')
def index():
    name = "This is the route. If you want to check the API 'hello_World' add /hello if you want to check the weather add '/clima/<city>' "
    return name

@app.route('/hello')
def hello():
    name = "Hello world!"
    return name
@app.route("/clima/<string:ciudad>")
def lima(ciudad):
    conn.request("GET", "/find?q="+ciudad+"&cnt=1&mode=null&lon=0&type=link%2C%20accurate&lat=0&units=metric", headers=headers)
    res = conn.getresponse()
    data = json.loads(res.read())
    result = data['list']
    if(len(result) == 0):
        return("Add a valid city to clima/ path")
    else:
        for d in result:
            temp= d['main']
        resultTemp =temp['temp']
        return('El Clima para la ciudad: {} es {} °C'.format(ciudad,resultTemp))
if __name__ == "__main__":
    app.run(port=7777)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




