Plase import Flask if lib if you don't have it yet this is the instruction "$ pip install Flask"

The code is in Python
The hello Work API is execute add the Path /hello
For the API that check the temperature use the path /clima/<city>